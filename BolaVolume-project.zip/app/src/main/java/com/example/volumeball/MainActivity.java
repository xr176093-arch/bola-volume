package com.example.volumeball;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {

    private SharedPreferences sp;
    private View preview;
    private Switch swEnable, swHide;
    private SeekBar sbSize, sbAlpha, sbR, sbG, sbB;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private int val(SeekBar s) {
        return s.getProgress() + (Integer) s.getTag();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(48), dp(24), dp(40));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Bola Volume");
        title.setTextSize(26);
        root.addView(title);

        swEnable = new Switch(this);
        swEnable.setText("Aktifkan bola mengambang");
        swEnable.setTextSize(18);
        swEnable.setPadding(0, dp(24), 0, dp(16));
        root.addView(swEnable);

        // Kotak pratinjau bola
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(120)));
        preview = new View(this);
        box.addView(preview);
        root.addView(box);

        int color = sp.getInt("color", Color.parseColor("#2196F3"));
        sbSize = addSeek(root, "Ukuran bola", " dp", 36, 100, sp.getInt("size", 56));
        sbAlpha = addSeek(root, "Transparansi (opacity)", "%", 20, 100, sp.getInt("alpha", 90));
        sbR = addSeek(root, "Warna - Merah", "", 0, 255, Color.red(color));
        sbG = addSeek(root, "Warna - Hijau", "", 0, 255, Color.green(color));
        sbB = addSeek(root, "Warna - Biru", "", 0, 255, Color.blue(color));

        swHide = new Switch(this);
        swHide.setText("Sembunyikan saat layar penuh (video/game)");
        swHide.setTextSize(16);
        swHide.setPadding(0, dp(24), 0, 0);
        swHide.setChecked(sp.getBoolean("hideFull", true));
        swHide.setOnCheckedChangeListener((btn, on) -> saveConfig());
        root.addView(swHide);

        updatePreview();
        setContentView(scroll);

        swEnable.setChecked(sp.getBoolean("enabled", false) && Settings.canDrawOverlays(this));
        swEnable.setOnCheckedChangeListener((btn, on) -> {
            if (on) {
                if (!Settings.canDrawOverlays(this)) {
                    swEnable.setChecked(false);
                    sp.edit().putBoolean("enabled", true).apply();
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                    return;
                }
                sp.edit().putBoolean("enabled", true).apply();
                startForegroundService(new Intent(this, FloatBallService.class));
            } else {
                sp.edit().putBoolean("enabled", false).apply();
                stopService(new Intent(this, FloatBallService.class));
            }
        });
    }

    private SeekBar addSeek(LinearLayout parent, final String name, final String unit,
                            final int min, int max, int value) {
        final TextView label = new TextView(this);
        label.setTextSize(16);
        label.setPadding(0, dp(16), 0, 0);
        label.setText(name + ": " + value + unit);
        parent.addView(label);

        SeekBar s = new SeekBar(this);
        s.setTag(min);
        s.setMax(max - min);
        s.setProgress(value - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                label.setText(name + ": " + (p + min) + unit);
                if (user) saveConfig();
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        parent.addView(s);
        return s;
    }

    private void saveConfig() {
        int c = Color.rgb(val(sbR), val(sbG), val(sbB));
        sp.edit()
                .putInt("color", c)
                .putInt("size", val(sbSize))
                .putInt("alpha", val(sbAlpha))
                .putBoolean("hideFull", swHide.isChecked())
                .apply();
        updatePreview();
        if (swEnable.isChecked()) {
            startService(new Intent(this, FloatBallService.class)); // refresh bola
        }
    }

    private void updatePreview() {
        int size = val(sbSize);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.rgb(val(sbR), val(sbG), val(sbB)));
        d.setStroke(dp(Math.max(2, size / 20)), Color.WHITE);
        preview.setBackground(d);
        preview.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        preview.setAlpha(val(sbAlpha) / 100f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // setelah user memberi izin overlay lalu kembali ke aplikasi
        if (swEnable != null && !swEnable.isChecked() && Settings.canDrawOverlays(this)
                && sp.getBoolean("enabled", false)) {
            swEnable.setChecked(true);
        }
    }
}
