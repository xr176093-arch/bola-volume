package com.example.volumeball;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {

    private SharedPreferences sp;
    private View preview;
    private Switch sw;
    private SeekBar sbR, sbG, sbB;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(48), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("Bola Volume");
        title.setTextSize(26);
        root.addView(title);

        sw = new Switch(this);
        sw.setText("Aktifkan bola mengambang");
        sw.setTextSize(18);
        sw.setPadding(0, dp(24), 0, dp(24));
        root.addView(sw);

        TextView lbl = new TextView(this);
        lbl.setText("Warna bola");
        lbl.setTextSize(18);
        root.addView(lbl);

        preview = new View(this);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(64), dp(64));
        pp.topMargin = dp(12);
        preview.setLayoutParams(pp);
        root.addView(preview);

        int color = sp.getInt("color", Color.parseColor("#2196F3"));
        sbR = addSeek(root, "Merah", Color.red(color));
        sbG = addSeek(root, "Hijau", Color.green(color));
        sbB = addSeek(root, "Biru", Color.blue(color));
        updatePreview();

        setContentView(root);

        sw.setChecked(sp.getBoolean("enabled", false) && Settings.canDrawOverlays(this));
        sw.setOnCheckedChangeListener((btn, on) -> {
            if (on) {
                if (!Settings.canDrawOverlays(this)) {
                    sw.setChecked(false);
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                    return;
                }
                sp.edit().putBoolean("enabled", true).apply();
                startForegroundService(new Intent(this, FloatBallService.class));
            } else {
                sp.edit().putBoolean("enabled", false).apply();
                stopService(new Intent(this, FloatBallService.class));
            }
        });
    }

    private SeekBar addSeek(LinearLayout root, String name, int value) {
        TextView t = new TextView(this);
        t.setText(name);
        t.setPadding(0, dp(16), 0, 0);
        root.addView(t);
        SeekBar s = new SeekBar(this);
        s.setMax(255);
        s.setProgress(value);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                if (user) saveColor();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        root.addView(s);
        return s;
    }

    private void saveColor() {
        int c = Color.rgb(sbR.getProgress(), sbG.getProgress(), sbB.getProgress());
        sp.edit().putInt("color", c).apply();
        updatePreview();
        if (sw.isChecked()) {
            startService(new Intent(this, FloatBallService.class)); // refresh warna
        }
    }

    private void updatePreview() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(Color.rgb(sbR.getProgress(), sbG.getProgress(), sbB.getProgress()));
        d.setStroke(dp(3), Color.WHITE);
        preview.setBackground(d);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // setelah user memberi izin overlay lalu kembali ke app
        if (sw != null && !sw.isChecked() && Settings.canDrawOverlays(this)
                && sp.getBoolean("enabled", false)) {
            sw.setChecked(true);
        }
    }
}
