package com.example.volumeball;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatBallService extends Service {

    private static final int GAP_DP = 8;

    private WindowManager wm;
    private AudioManager am;
    private SharedPreferences sp;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LinearLayout root;
    private TextView ball, btnUp, btnDown;
    private WindowManager.LayoutParams lp;

    private View probe;            // jendela pengintai untuk deteksi layar penuh
    private boolean expanded = false;
    private boolean hiddenByFullscreen = false;
    private int currentBtnDp = 45;
    private int lastPercent = -1;
    private int lastStream = -1;

    private static final int[] STREAMS = {
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_NOTIFICATION,
            AudioManager.STREAM_RING,
            AudioManager.STREAM_ALARM,
            AudioManager.STREAM_VOICE_CALL};
    private static final String[] NAMES = {"Media", "Notifikasi", "Dering", "Alarm", "Panggilan"};
    private TextView streamBtn;
    private LinearLayout streamList;
    private final TextView[] streamItems = new TextView[5];

    // Dijalankan tiap 0,5 detik: update persen volume & cek layar penuh
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updatePercent();
            checkFullscreen();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                "ball", "Bola Volume", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "ball")
                .setContentTitle("Bola Volume aktif")
                .setContentText("Buka aplikasi untuk menonaktifkan")
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .build();
        startForeground(1, n);

        buildBall();
        applyConfig();
        buildProbe();
        handler.post(tick);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView makeCircle(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        return t;
    }

    private void buildBall() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        btnUp = makeCircle("+");
        ball = makeCircle("--");
        btnDown = makeCircle("\u2212");
        btnUp.setVisibility(View.GONE);
        btnDown.setVisibility(View.GONE);

        root.addView(btnUp);
        root.addView(ball);
        root.addView(btnDown);

        // Tombol pilihan jenis volume (muncul saat bola diketuk)
        streamBtn = makePill("Media");
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sbp.topMargin = dp(GAP_DP);
        streamBtn.setLayoutParams(sbp);
        streamBtn.setVisibility(View.GONE);
        streamBtn.setOnClickListener(v -> streamList.setVisibility(
                streamList.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));

        streamList = new LinearLayout(this);
        streamList.setOrientation(LinearLayout.VERTICAL);
        streamList.setGravity(Gravity.CENTER_HORIZONTAL);
        streamList.setVisibility(View.GONE);
        for (int i = 0; i < NAMES.length; i++) {
            final int idx = i;
            TextView it = makePill(NAMES[i]);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            ip.topMargin = dp(4);
            it.setLayoutParams(ip);
            it.setOnClickListener(v -> selectStream(idx));
            streamItems[i] = it;
            streamList.addView(it);
        }
        root.addView(streamBtn);
        root.addView(streamList);

        setupRepeat(btnUp, AudioManager.ADJUST_RAISE);
        setupRepeat(btnDown, AudioManager.ADJUST_LOWER);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0;
        lp.y = dp(200);

        // Geser (drag) & ketuk bola
        ball.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - touchX);
                        int dy = (int) (e.getRawY() - touchY);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            lp.x = startX + dx;
                            lp.y = startY + dy;
                            wm.updateViewLayout(root, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleExpand();
                        return true;
                }
                return false;
            }
        });

        wm.addView(root, lp);
    }

    // Tombol + / - : tahan lama = volume terus naik/turun
    private void setupRepeat(final TextView b, final int direction) {
        final Runnable[] repeat = new Runnable[1];
        repeat[0] = new Runnable() {
            @Override
            public void run() {
                changeVolume(direction);
                handler.postDelayed(repeat[0], 110);
            }
        };
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setAlpha(0.6f);
                        changeVolume(direction);
                        handler.postDelayed(repeat[0], 400);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setAlpha(1f);
                        handler.removeCallbacks(repeat[0]);
                        return true;
                }
                return true;
            }
        });
    }

    private int pickStream() {
        int i = sp.getInt("stream", 0);
        if (i < 0 || i >= STREAMS.length) i = 0;
        return STREAMS[i];
    }

    private void changeVolume(int direction) {
        try {
            am.adjustStreamVolume(pickStream(), direction, 0);
        } catch (SecurityException e) {
            // Mode Jangan Ganggu (DND) menolak perubahan volume dering/notifikasi
        }
        updatePercent();
    }

    private void updatePercent() {
        int stream = pickStream();
        int max = am.getStreamMaxVolume(stream);
        int cur = am.getStreamVolume(stream);
        int p = max <= 0 ? 0 : Math.round(cur * 100f / max);
        if (p != lastPercent || stream != lastStream) {
            lastPercent = p;
            lastStream = stream;
            ball.setText(p + "%");
        }
    }

    private void toggleExpand() {
        expanded = !expanded;
        int vis = expanded ? View.VISIBLE : View.GONE;
        btnUp.setVisibility(vis);
        btnDown.setVisibility(vis);
        streamBtn.setVisibility(vis);
        if (!expanded) streamList.setVisibility(View.GONE);
        int shift = dp(currentBtnDp) + dp(GAP_DP);
        lp.y += expanded ? -shift : shift;
        wm.updateViewLayout(root, lp);
    }

    private void collapse() {
        if (!expanded) return;
        expanded = false;
        btnUp.setVisibility(View.GONE);
        btnDown.setVisibility(View.GONE);
        streamBtn.setVisibility(View.GONE);
        streamList.setVisibility(View.GONE);
        lp.y += dp(currentBtnDp) + dp(GAP_DP);
        wm.updateViewLayout(root, lp);
    }

    private void resize(View v, int sizeDp, int topMarginPx, int bottomMarginPx) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        p.topMargin = topMarginPx;
        p.bottomMargin = bottomMarginPx;
        v.setLayoutParams(p);
    }

    private void paint(TextView t, int color, int sizeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(Math.max(2, sizeDp / 20)), Color.WHITE);
        t.setBackground(d);
    }

    // Terapkan warna, ukuran, dan transparansi dari pengaturan
    private void applyConfig() {
        collapse();

        int color = sp.getInt("color", Color.parseColor("#2196F3"));
        int sizeDp = sp.getInt("size", 56);
        int alphaPct = sp.getInt("alpha", 90);
        currentBtnDp = Math.round(sizeDp * 0.8f);

        resize(btnUp, currentBtnDp, 0, dp(GAP_DP));
        resize(ball, sizeDp, 0, 0);
        resize(btnDown, currentBtnDp, dp(GAP_DP), 0);

        paint(btnUp, color, currentBtnDp);
        paint(ball, color, sizeDp);
        paint(btnDown, color, currentBtnDp);

        ball.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sizeDp * 0.27f);
        btnUp.setTextSize(TypedValue.COMPLEX_UNIT_DIP, currentBtnDp * 0.55f);
        btnDown.setTextSize(TypedValue.COMPLEX_UNIT_DIP, currentBtnDp * 0.55f);

        root.setAlpha(alphaPct / 100f);
        paintPills();
    }

    private TextView makePill(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setMinWidth(dp(96));
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        return t;
    }

    private void stylePill(TextView t, int color, boolean selected, float textSizeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setCornerRadius(dp(16));
        d.setColor(selected ? Color.WHITE : color);
        d.setStroke(dp(2), selected ? color : Color.WHITE);
        t.setBackground(d);
        t.setTextColor(selected ? color : Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, textSizeDp);
    }

    private void paintPills() {
        int color = sp.getInt("color", Color.parseColor("#2196F3"));
        int sizeDp = sp.getInt("size", 56);
        int sel = sp.getInt("stream", 0);
        float ts = Math.max(11f, sizeDp * 0.24f);
        stylePill(streamBtn, color, false, ts);
        for (int i = 0; i < streamItems.length; i++) {
            stylePill(streamItems[i], color, i == sel, ts);
        }
        streamBtn.setText(NAMES[sel] + " \u25BE");
    }

    private void selectStream(int index) {
        sp.edit().putInt("stream", index).apply();
        streamList.setVisibility(View.GONE);
        paintPills();
        updatePercent();
    }

    // ---- Deteksi layar penuh ----
    private void buildProbe() {
        probe = new View(this);
        WindowManager.LayoutParams pl = new WindowManager.LayoutParams(
                1,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        pl.gravity = Gravity.TOP | Gravity.START;
        wm.addView(probe, pl);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    // Jendela pengintai ada di bawah status bar. Jika status bar hilang
    // (video/game layar penuh), posisinya naik ke paling atas layar.
    private void checkFullscreen() {
        boolean fullscreen = false;
        if (sp.getBoolean("hideFull", true)) {
            int[] loc = new int[2];
            probe.getLocationOnScreen(loc);
            int sb = statusBarHeight();
            fullscreen = sb > 0 && loc[1] < sb / 2;
        }
        if (fullscreen != hiddenByFullscreen) {
            hiddenByFullscreen = fullscreen;
            root.setVisibility(fullscreen ? View.GONE : View.VISIBLE);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        applyConfig(); // dipanggil ulang saat pengaturan diubah dari aplikasi
        updatePercent();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (root != null) wm.removeView(root);
        if (probe != null) wm.removeView(probe);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
