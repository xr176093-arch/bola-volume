package com.example.volumeball;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatBallService extends Service {

    private static final int GAP_DP = 8;
    private static final int DEFAULT_COLOR = 0xFF2196F3;
    private static final long IDLE_MS = 3000;     // kembali ke warna normal setelah 3 detik tanpa sentuhan
    private static final long REVEAL_MS = 4500;   // lama bola muncul setelah tarik toolbar di layar penuh

    private static final int[] STREAMS = {
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_NOTIFICATION,
            AudioManager.STREAM_RING,
            AudioManager.STREAM_ALARM,
            AudioManager.STREAM_VOICE_CALL};
    private static final String[] NAMES = {"Media", "Notifikasi", "Dering", "Alarm", "Panggilan"};

    private WindowManager wm;
    private AudioManager am;
    private SharedPreferences sp;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LinearLayout root;
    private TextView ball, btnUp, btnDown, streamBtn;
    private LinearLayout streamList;
    private final TextView[] streamItems = new TextView[5];
    private WindowManager.LayoutParams lp;
    private boolean added = false;

    private View probe;       // pengintai: mendeteksi status bar hilang (layar penuh)
    private View topStrip;    // garis tipis di tepi atas saat layar penuh: mendeteksi tarikan toolbar
    private float stripDownY;

    private boolean expanded = false;
    private int currentBtnDp = 45;
    private int lastPercent = -1;
    private int lastStream = -1;

    // Posisi bola: pusat horizontal (cx) & sisi atas (by) dalam piksel,
    // disimpan juga sebagai pecahan layar (fx, fy) agar tetap proporsional saat diputar.
    private int cx, by;
    private float fx, fy;
    private int lastW = -1, lastH = -1;

    // Efek menyala
    private float glow = 0f;
    private ValueAnimator glowAnim;
    private final Runnable unglow = new Runnable() {
        @Override
        public void run() {
            animateGlow(0f);
        }
    };

    // Layar penuh
    private boolean inFullscreen = false;
    private boolean hiddenByFullscreen = false;
    private long revealUntil = 0;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updatePercent();
            int[] sc = screenSize();
            if (sc[0] != lastW || sc[1] != lastH) applyPositionFromFractions();
            checkFullscreen();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                "ball", "Bola Volume", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "ball")
                .setContentTitle("Bola Volume aktif")
                .setContentText("Buka aplikasi untuk menonaktifkan")
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .build();
        startForeground(1, n);

        buildBall();
        applyConfig();
        buildProbe();
        buildStrip();
        handler.post(tick);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private int clamp(int v, int lo, int hi) {
        if (hi < lo) return lo;
        return Math.max(lo, Math.min(hi, v));
    }

    private int[] screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getMaximumWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private TextView makeCircle(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        return t;
    }

    private TextView makePill(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setMinWidth(dp(96));
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        return t;
    }

    private void buildBall() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        btnUp = makeCircle("+");
        ball = makeCircle("--");
        btnDown = makeCircle("\u2212");
        btnUp.setVisibility(View.GONE);
        btnDown.setVisibility(View.GONE);

        root.addView(btnUp);
        root.addView(ball);
        root.addView(btnDown);

        // Pilihan jenis volume
        streamBtn = makePill("Media");
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sbp.topMargin = dp(GAP_DP);
        streamBtn.setLayoutParams(sbp);
        streamBtn.setVisibility(View.GONE);
        streamBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pulse();
                streamList.setVisibility(
                        streamList.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                layoutRoot();
            }
        });

        streamList = new LinearLayout(this);
        streamList.setOrientation(LinearLayout.VERTICAL);
        streamList.setGravity(Gravity.CENTER_HORIZONTAL);
        streamList.setVisibility(View.GONE);
        for (int i = 0; i < NAMES.length; i++) {
            final int idx = i;
            TextView it = makePill(NAMES[i]);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            ip.topMargin = dp(4);
            it.setLayoutParams(ip);
            it.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectStream(idx);
                }
            });
            streamItems[i] = it;
            streamList.addView(it);
        }
        root.addView(streamBtn);
        root.addView(streamList);

        setupRepeat(btnUp, AudioManager.ADJUST_RAISE);
        setupRepeat(btnDown, AudioManager.ADJUST_LOWER);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        fx = sp.getFloat("fx", 0.08f);
        fy = sp.getFloat("fy", 0.30f);
        int[] sc = screenSize();
        lastW = sc[0];
        lastH = sc[1];
        cx = (int) (fx * sc[0]);
        by = (int) (fy * sc[1]);

        ball.setOnTouchListener(new View.OnTouchListener() {
            int startCx, startBy;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startCx = cx;
                        startBy = by;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        pulse();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - touchX);
                        int dy = (int) (e.getRawY() - touchY);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            cx = startCx + dx;
                            by = startBy + dy;
                            layoutRoot();   // dijepit agar tidak keluar layar
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            toggleExpand();
                        } else {
                            savePosition();
                        }
                        return true;
                }
                return false;
            }
        });

        wm.addView(root, lp);
        added = true;
    }

    // ---- Posisi & batas layar ----
    private void layoutRoot() {
        if (!added) return;
        root.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int w = root.getMeasuredWidth();
        int h = root.getMeasuredHeight();
        int[] sc = screenSize();
        int above = expanded ? dp(currentBtnDp) + dp(GAP_DP) : 0;

        cx = clamp(cx, w / 2, sc[0] - (w - w / 2));
        by = clamp(by, above, sc[1] - (h - above));

        lp.x = cx - w / 2;
        lp.y = by - above;
        wm.updateViewLayout(root, lp);
    }

    private void savePosition() {
        int[] sc = screenSize();
        fx = cx / (float) sc[0];
        fy = by / (float) sc[1];
        sp.edit().putFloat("fx", fx).putFloat("fy", fy).apply();
    }

    private void applyPositionFromFractions() {
        int[] sc = screenSize();
        lastW = sc[0];
        lastH = sc[1];
        cx = (int) (fx * sc[0]);
        by = (int) (fy * sc[1]);
        layoutRoot();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        handler.post(new Runnable() {
            @Override
            public void run() {
                applyPositionFromFractions();
            }
        });
    }

    // ---- Panel ----
    private void setPanelVisible(boolean on) {
        int vis = on ? View.VISIBLE : View.GONE;
        btnUp.setVisibility(vis);
        btnDown.setVisibility(vis);
        streamBtn.setVisibility(vis);
        if (!on) streamList.setVisibility(View.GONE);
    }

    private void toggleExpand() {
        expanded = !expanded;
        setPanelVisible(expanded);
        layoutRoot();
        savePosition();
    }

    private void collapse() {
        if (!expanded) return;
        expanded = false;
        setPanelVisible(false);
        layoutRoot();
    }

    // ---- Volume ----
    private void setupRepeat(final TextView b, final int direction) {
        final Runnable[] repeat = new Runnable[1];
        repeat[0] = new Runnable() {
            @Override
            public void run() {
                pulse();
                changeVolume(direction);
                handler.postDelayed(repeat[0], 110);
            }
        };
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setAlpha(0.6f);
                        pulse();
                        changeVolume(direction);
                        handler.postDelayed(repeat[0], 400);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setAlpha(1f);
                        handler.removeCallbacks(repeat[0]);
                        return true;
                }
                return true;
            }
        });
    }

    private int pickStream() {
        int i = sp.getInt("stream", 0);
        if (i < 0 || i >= STREAMS.length) i = 0;
        return STREAMS[i];
    }

    private void changeVolume(int direction) {
        try {
            am.adjustStreamVolume(pickStream(), direction, 0);
        } catch (SecurityException e) {
            // Mode Jangan Ganggu (DND) menolak perubahan volume dering/notifikasi
        }
        updatePercent();
    }

    private void updatePercent() {
        int stream = pickStream();
        int max = am.getStreamMaxVolume(stream);
        int cur = am.getStreamVolume(stream);
        int p = max <= 0 ? 0 : Math.round(cur * 100f / max);
        if (p != lastPercent || stream != lastStream) {
            lastPercent = p;
            lastStream = stream;
            ball.setText(p + "%");
        }
    }

    private void selectStream(int index) {
        pulse();
        sp.edit().putInt("stream", index).apply();
        streamList.setVisibility(View.GONE);
        repaint();
        updatePercent();
        layoutRoot();
    }

    // ---- Tampilan: warna, ukuran, efek menyala ----
    private int blend(int c, int to, float t) {
        int r = (int) (Color.red(c) + (Color.red(to) - Color.red(c)) * t);
        int g = (int) (Color.green(c) + (Color.green(to) - Color.green(c)) * t);
        int b = (int) (Color.blue(c) + (Color.blue(to) - Color.blue(c)) * t);
        return Color.rgb(r, g, b);
    }

    // Dipanggil setiap ada sentuhan: bola menyala, lalu kembali normal setelah IDLE_MS
    private void pulse() {
        animateGlow(1f);
        handler.removeCallbacks(unglow);
        handler.postDelayed(unglow, IDLE_MS);
        if (inFullscreen) {
            revealUntil = Math.max(revealUntil, SystemClock.uptimeMillis() + REVEAL_MS);
        }
    }

    private void animateGlow(float target) {
        if (glowAnim != null) glowAnim.cancel();
        glowAnim = ValueAnimator.ofFloat(glow, target);
        glowAnim.setDuration(250);
        glowAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                glow = (Float) a.getAnimatedValue();
                repaint();
            }
        });
        glowAnim.start();
    }

    private void resize(View v, int sizeDp, int topMarginPx, int bottomMarginPx) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        p.topMargin = topMarginPx;
        p.bottomMargin = bottomMarginPx;
        v.setLayoutParams(p);
    }

    private void paint(TextView t, int color, int sizeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(Math.max(2, sizeDp / 20)), Color.WHITE);
        t.setBackground(d);
    }

    private void stylePill(TextView t, int color, boolean selected, float textSizeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setCornerRadius(dp(16));
        d.setColor(selected ? Color.WHITE : color);
        d.setStroke(dp(2), selected ? color : Color.WHITE);
        t.setBackground(d);
        t.setTextColor(selected ? color : Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, textSizeDp);
    }

    private void repaint() {
        int base = sp.getInt("color", DEFAULT_COLOR);
        int sizeDp = sp.getInt("size", 56);
        int sel = sp.getInt("stream", 0);
        if (sel < 0 || sel >= NAMES.length) sel = 0;

        // Menyala = warna dicampur putih
        int color = blend(base, Color.WHITE, 0.35f * glow);

        paint(btnUp, color, currentBtnDp);
        paint(ball, color, sizeDp);
        paint(btnDown, color, currentBtnDp);

        // Persen: tersembunyi saat diam, muncul (terang + bercahaya) saat disentuh
        ball.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sizeDp * 0.27f * (1f + 0.12f * glow));
        ball.setTextColor(Color.argb((int) (255 * glow), 255, 255, 255));
        ball.setShadowLayer(dp(8) * glow, 0f, 0f, Color.WHITE);
        btnUp.setTextSize(TypedValue.COMPLEX_UNIT_DIP, currentBtnDp * 0.55f);
        btnDown.setTextSize(TypedValue.COMPLEX_UNIT_DIP, currentBtnDp * 0.55f);

        float ts = Math.max(11f, sizeDp * 0.24f);
        stylePill(streamBtn, color, false, ts);
        for (int i = 0; i < streamItems.length; i++) {
            stylePill(streamItems[i], color, i == sel, ts);
        }
        streamBtn.setText(NAMES[sel] + " \u25BE");
    }

    private void applyConfig() {
        collapse();

        int sizeDp = sp.getInt("size", 56);
        int alphaPct = sp.getInt("alpha", 90);
        currentBtnDp = Math.round(sizeDp * 0.8f);

        resize(btnUp, currentBtnDp, 0, dp(GAP_DP));
        resize(ball, sizeDp, 0, 0);
        resize(btnDown, currentBtnDp, dp(GAP_DP), 0);

        root.setAlpha(alphaPct / 100f);
        repaint();
        layoutRoot();
    }

    // ---- Layar penuh ----
    private void buildProbe() {
        probe = new View(this);
        WindowManager.LayoutParams pl = new WindowManager.LayoutParams(
                1,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        pl.gravity = Gravity.TOP | Gravity.START;
        wm.addView(probe, pl);
    }

    // Garis tipis di tepi atas layar, hanya aktif saat layar penuh.
    // Tarikan ke bawah dari tepi atas = pengguna memunculkan toolbar -> bola ikut muncul sebentar.
    private void buildStrip() {
        topStrip = new View(this);
        topStrip.setVisibility(View.GONE);
        topStrip.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        stripDownY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (e.getRawY() - stripDownY > dp(10)) {
                            revealUntil = SystemClock.uptimeMillis() + REVEAL_MS;
                            checkFullscreen();
                        }
                        return true;
                }
                return true;
            }
        });
        WindowManager.LayoutParams sl = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                dp(18),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        sl.gravity = Gravity.TOP | Gravity.START;
        wm.addView(topStrip, sl);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private void checkFullscreen() {
        boolean fullscreen = false;
        if (sp.getBoolean("hideFull", true)) {
            int[] loc = new int[2];
            probe.getLocationOnScreen(loc);
            int sb = statusBarHeight();
            fullscreen = sb > 0 && loc[1] < sb / 2;
        }
        if (fullscreen != inFullscreen) {
            inFullscreen = fullscreen;
            topStrip.setVisibility(fullscreen ? View.VISIBLE : View.GONE);
            if (!fullscreen) revealUntil = 0;
        }
        boolean revealed = SystemClock.uptimeMillis() < revealUntil;
        boolean hide = fullscreen && !revealed;
        if (hide != hiddenByFullscreen) {
            hiddenByFullscreen = hide;
            root.setVisibility(hide ? View.GONE : View.VISIBLE);
            if (!hide) layoutRoot();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        applyConfig();
        updatePercent();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (glowAnim != null) glowAnim.cancel();
        if (root != null) wm.removeView(root);
        if (probe != null) wm.removeView(probe);
        if (topStrip != null) wm.removeView(topStrip);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
