package com.example.volumeball;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatBallService extends Service {

    private WindowManager wm;
    private AudioManager am;
    private LinearLayout root;
    private TextView ball, btnUp, btnDown;
    private WindowManager.LayoutParams lp;
    private boolean expanded = false;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                "ball", "Bola Volume", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "ball")
                .setContentTitle("Bola Volume aktif")
                .setContentText("Buka aplikasi untuk menonaktifkan")
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .build();
        startForeground(1, n);

        buildBall();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView makeCircle(String text, int sizeDp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        p.topMargin = dp(8);
        t.setLayoutParams(p);
        return t;
    }

    private void buildBall() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        btnUp = makeCircle("+", 46);
        ball = makeCircle("", 56);
        btnDown = makeCircle("\u2212", 46);
        btnUp.setVisibility(View.GONE);
        btnDown.setVisibility(View.GONE);

        root.addView(btnUp);
        root.addView(ball);
        root.addView(btnDown);

        btnUp.setOnClickListener(v ->
                am.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI));
        btnDown.setOnClickListener(v ->
                am.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI));

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0;
        lp.y = dp(200);

        // Geser (drag) & ketuk bola
        ball.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x; startY = lp.y;
                        touchX = e.getRawX(); touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - touchX);
                        int dy = (int) (e.getRawY() - touchY);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            lp.x = startX + dx;
                            lp.y = startY + dy;
                            wm.updateViewLayout(root, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleExpand();
                        return true;
                }
                return false;
            }
        });

        applyColor();
        wm.addView(root, lp);
    }

    private void toggleExpand() {
        expanded = !expanded;
        int vis = expanded ? View.VISIBLE : View.GONE;
        btnUp.setVisibility(vis);
        btnDown.setVisibility(vis);
        // jaga posisi bola tetap di tempat saat tombol + muncul di atasnya
        int shift = dp(46 + 8);
        lp.y += expanded ? -shift : shift;
        wm.updateViewLayout(root, lp);
    }

    private void applyColor() {
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        int color = sp.getInt("color", Color.parseColor("#2196F3"));
        for (TextView t : new TextView[]{btnUp, ball, btnDown}) {
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(color);
            d.setStroke(dp(3), Color.WHITE);
            t.setBackground(d);
            t.setAlpha(t == ball ? 0.9f : 1f);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        applyColor(); // dipanggil ulang saat warna diubah dari aplikasi
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (root != null) wm.removeView(root);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
